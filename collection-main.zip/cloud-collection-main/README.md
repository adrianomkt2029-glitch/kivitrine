# Your Creative Spark

https://lovable.dev/projects/6c934f89-73d4-4b77-8086-6b2cf8e02960

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://vitrine-store.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/591cf2dc-2f94-4d7a-8994-3b72b6b3dd7d).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
