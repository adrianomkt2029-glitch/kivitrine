# Migração do banco — Lovable Cloud → Supabase externo

Arquivos nesta pasta (execute **nesta ordem** no SQL Editor do novo projeto):

| Ordem | Arquivo | O que faz |
|---|---|---|
| 1 | `01-estrutura.sql` | Tipos, funções, tabelas, GRANTs, RLS, políticas, triggers e índices |
| 2 | `02-dados.sql` | Todos os registros atuais: 9 categorias, 8 produtos, 2 configurações (banner e botão de ajuda). `leads` está vazia. |
| 3 | `03-storage.sql` | Bucket `loja` (privado) + política de acesso do admin |
| 4 | `04-admin.sql` | Dá papel de administrador ao seu e-mail (rodar após criar o usuário) |

---

## Passo a passo

### 1. Crie o projeto Supabase
Região mais próxima (ex.: São Paulo), guarde a **senha do banco**. Anote em *Project Settings → API*:
- `Project URL`
- `anon / publishable key`
- `service_role / secret key` (nunca vai para o frontend)

### 2. Rode a estrutura
SQL Editor → New query → cole **todo** o `01-estrutura.sql` → Run.
Deve terminar sem erro. Confira em *Table Editor* as 5 tabelas: `categorias`, `produtos`, `configuracoes`, `leads`, `user_roles`.

### 3. Rode os dados
SQL Editor → cole `02-dados.sql` → Run. Ele está dentro de `BEGIN/COMMIT`: se algo falhar, nada é gravado.
Verificação rápida:
```sql
select (select count(*) from categorias) as categorias,
       (select count(*) from produtos)   as produtos,
       (select count(*) from configuracoes) as configuracoes;
-- esperado: 9 | 8 | 2
```

### 4. Configure Auth
- *Authentication → Providers → Email*: habilitado.
- Para testar rápido sem caixa de entrada: *Confirm email* **desligado** (ligue depois em produção).
- Se quiser usar a senha `123456789`, desligue *Password → Prevent use of leaked passwords*. **Boa prática: manter ligado e usar senha forte.**
- *Authentication → URL Configuration*: `Site URL` = domínio do seu app; adicione as *Redirect URLs* (`http://localhost:8080/**` e `https://seudominio.com/**`) — sem isso, login social e reset de senha falham.

### 5. Crie o usuário admin e rode o `04-admin.sql`
*Authentication → Users → Add user* com `diano.baiano2015@gmail.com` (marque "Auto confirm"). Depois rode `04-admin.sql`.
> Usuários **não** são migrados junto com as tabelas: `auth.users` pertence ao Supabase e os IDs são novos. Se houvesse muitos usuários, o caminho seria a Admin API (`POST /auth/v1/admin/users`) com os hashes de senha.

### 6. Storage (imagens e vídeos)
Rode `03-storage.sql` (ou crie o bucket `loja` pelo painel, privado).

Arquivos hoje existentes no bucket atual (3):
```
produtos/5a45a7c7-dc28-4d01-a2e5-6e3707b6f7f0.png
produtos/a8e9ae57-a017-420f-83f0-d9164025a287.png
videos/e1da85d7-44b9-4520-8c9e-ecdd2f9e4bf3.mp4
```
Eles são resíduos de teste e **não** estão sendo usados por nenhum produto — pode ignorá-los. Se ainda quiser copiá-los, baixe pelo painel de backend atual (Storage → bucket `loja` → download) e faça upload no novo bucket mantendo os mesmos caminhos (`produtos/...`, `videos/...`).

**Imagens realmente usadas pelos produtos:** 7 delas apontam para arquivos do próprio app (caminhos relativos `/__l5e/assets-v1/.../nome.jpg`, que vêm de `src/assets/`) e 1 aponta para um link externo (`minio.afcode.com.br`). Como são caminhos relativos ao site, **continuam funcionando** no novo projeto sem nenhuma ação — a migração do banco não afeta esses arquivos, pois eles moram no código, não no Storage.

Se preferir centralizar tudo no Storage do novo Supabase:
1. Baixe as imagens de `src/assets/` (ou abra `https://vitrine-store.lovable.app/__l5e/assets-v1/...`).
2. Faça upload no bucket `loja`, pasta `produtos/`.
3. Se o bucket for público, atualize os links:
```sql
UPDATE public.produtos
SET imagem_url       = 'https://SEU-PROJETO.supabase.co/storage/v1/object/public/loja/produtos/whatsapp.jpg',
    popup_imagem_url = 'https://SEU-PROJETO.supabase.co/storage/v1/object/public/loja/produtos/whatsapp.jpg'
WHERE titulo = 'Zap Modelo Pro';
```
(bucket privado → use links assinados gerados pelo app, como já é feito hoje no upload do painel admin).

### 7. Aponte o app para o novo banco
No `.env` do projeto (ou nas variáveis do host):
```
VITE_SUPABASE_URL=https://SEU-PROJETO.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sua_anon_key
```
E no servidor (server functions): `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`.
Regenere os tipos, se quiser: `npx supabase gen types typescript --project-id SEU_REF > src/integrations/supabase/types.ts`.

### 8. Validação final (checklist)
- [ ] Home lista 4 destaques + 4 produtos da vitrine, com imagens
- [ ] Botão de vídeo abre o popup do YouTube
- [ ] Botões Comprar / Ver Demo abrem os links
- [ ] Login admin entra em `/admin` e lista os 8 produtos
- [ ] Editar/salvar produto funciona; upload de imagem funciona
- [ ] Banner e botão de ajuda editáveis em `/admin/banner` e `/admin/ajuda`
- [ ] Enviar um lead pelo site anônimo grava em `leads` (e só admin consegue ver)

---

## Boas práticas
- **Nunca** exponha a `service_role key` no frontend; use somente em server functions.
- Mantenha `role` sempre em `user_roles` + `has_role()` (SECURITY DEFINER). Guardar role no perfil abre escalada de privilégio.
- Todo `CREATE TABLE` em `public` precisa de `GRANT` + `ENABLE ROW LEVEL SECURITY` + políticas — RLS sozinho não basta e GRANT sozinho é inseguro.
- Rode o **Advisors → Security/Performance** do Supabase depois da migração e resolva os alertas.
- Ative *Point-in-time recovery* / backups diários antes de ir para produção.
- Versione novas mudanças como migrations (`supabase/migrations/*.sql`) em vez de editar direto pelo painel.
- Teste primeiro num projeto Supabase de rascunho; só depois rode no definitivo.
