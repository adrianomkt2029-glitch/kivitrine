import { HelpCircle, MessageCircle, Phone } from "lucide-react";
import { whatsappLink, type AjudaConfig } from "@/lib/loja";

const tamanhos = {
  pequeno: "px-4 py-2 text-xs",
  medio: "px-5 py-3 text-sm",
  grande: "px-7 py-4 text-base",
} as const;

export function HelpButton({ cfg }: { cfg: AjudaConfig }) {
  if (!cfg.ativo) return null;

  const Icon = cfg.icone === "chat" ? MessageCircle : cfg.icone === "telefone" ? Phone : cfg.icone === "ajuda" ? HelpCircle : MessageCircle;
  const pos = cfg.posicao === "bottom-left" ? "left-6" : "right-6";

  return (
    <a
      href={whatsappLink(cfg.numero, cfg.mensagem)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={cfg.texto}
      className={`fixed bottom-6 ${pos} z-50 inline-flex animate-pulse items-center gap-2 rounded-full font-semibold shadow-xl transition hover:scale-105 hover:animate-none ${tamanhos[cfg.tamanho] ?? tamanhos.medio}`}
      style={{
        backgroundColor: cfg.cor_fundo,
        color: cfg.cor_texto,
        boxShadow: `0 10px 30px -8px ${cfg.cor_fundo}`,
      }}
    >
      <Icon className="h-5 w-5" />
      {cfg.texto}
    </a>
  );
}
