import { ExternalLink, Globe, Play, Zap, X, ShoppingCart, ShieldCheck, Clock, Award, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { comParams, formatBRL, linkExterno, youtubeEmbed, type Produto } from "@/lib/loja";
import { imagemProduto } from "@/lib/produto-imagens";
import { Dialog, DialogClose, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

const btnCls =
  "inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl border px-3 text-sm font-bold transition hover:opacity-85";

export function ProductCard({ p }: { p: Produto }) {
  const preco = Number(p.preco);
  const precoAntigo = p.preco_antigo != null ? Number(p.preco_antigo) : null;
  const cor = p.comprar_cor || "#16a34a";

  const demoHref = linkExterno(p.demo_url);
  const checkoutHref = linkExterno(p.checkout_url);

  const [modalAberto, setModalAberto] = useState(false);
  const [videoModalAberto, setVideoModalAberto] = useState(false);

  const videoBruto = linkExterno(p.popup_video_url) || linkExterno(p.video_url) || demoHref;
  const tipoVideo = p.popup_video_tipo || "auto";
  const ehMp4 =
    tipoVideo === "mp4" || (tipoVideo === "auto" && /\.(mp4|webm|ogg)(\?|$)/i.test(videoBruto));
  const embedSrc =
    ehMp4
      ? videoBruto
      : tipoVideo === "iframe"
        ? videoBruto
        : comParams(youtubeEmbed(videoBruto), { autoplay: 1, rel: 0 });
  const temVideo = Boolean(videoBruto);
  const capaImagem = imagemProduto(p.imagem_url, p.titulo);
  const capaPopup = imagemProduto(p.popup_imagem_url || p.imagem_url, p.titulo);


  const abrirModal = () => setModalAberto(true);
  const fecharModal = (aberto: boolean) => setModalAberto(aberto);

  const abrirVideoModal = () => setVideoModalAberto(true);
  const fecharVideoModal = (aberto: boolean) => setVideoModalAberto(aberto);

  const renderVideo = () => (
    ehMp4 ? (
      <video src={embedSrc} controls autoPlay className="h-full w-full bg-black object-contain" />
    ) : (
      <iframe
        src={embedSrc}
        title={p.titulo}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="h-full w-full border-0 bg-black"
      />
    )
  );

  return (
    <>
      <article className="group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card shadow-[var(--shadow-card)] transition hover:-translate-y-1 hover:shadow-[var(--shadow-glow)]">
        <div className="relative aspect-[4/3] overflow-hidden rounded-t-xl bg-muted">
          {capaImagem ? (
            <img
              src={capaImagem}
              alt={p.titulo}
              loading="lazy"
              onClick={() => temVideo && abrirVideoModal()}
              className={
                "h-full w-full object-cover transition group-hover:scale-105 " + (temVideo ? "cursor-pointer" : "")
              }
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">Sem imagem</div>
          )}
          {p.desconto_ativo && p.desconto && (
            <span
              className="absolute left-3 top-3 rounded-md px-2 py-1 text-[10px] font-bold tracking-wide text-white"
              style={{ backgroundColor: p.desconto_cor }}
            >
              {p.desconto}
            </span>
          )}
          {p.selo && !p.desconto && (
            <span className="absolute left-3 top-3 rounded-md bg-foreground/85 px-2 py-1 text-[10px] font-bold tracking-wide text-background">
              {p.selo}
            </span>
          )}
          {(temVideo || demoHref) && (
            temVideo ? (
              <button
                type="button"
                onClick={abrirVideoModal}
                className="animate-soft-pulse absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold text-white shadow-md transition hover:opacity-90"
                style={{ backgroundColor: p.demo_cor }}
              >
                <ExternalLink className="h-3 w-3" /> Clique Aqui
              </button>
            ) : (
              <a
                href={demoHref}
                target="_blank"
                rel="noopener noreferrer"
                className="animate-soft-pulse absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-semibold text-white shadow-md transition hover:opacity-90"
                style={{ backgroundColor: p.demo_cor }}
              >
                <ExternalLink className="h-3 w-3" /> Clique Aqui
              </a>
            )
          )}
        </div>

        <div className="flex flex-1 flex-col p-4">
          <h3 className="min-h-[38px] text-[15px] font-bold leading-tight line-clamp-2">{p.titulo}</h3>
          <p className="mt-2 flex-1 text-xs leading-relaxed text-muted-foreground line-clamp-3">{p.descricao}</p>

          <div className="mt-4 min-h-[18px] text-xs font-semibold" style={{ color: "#dc2626" }}>
            {precoAntigo != null && precoAntigo > 0 && (
              <>
                de <span className="line-through">{formatBRL(precoAntigo)}</span> por:
              </>
            )}
          </div>

          <div
            className="mt-2 flex items-center justify-between gap-2 rounded-2xl border px-5 py-4"
            style={{
              borderColor: `color-mix(in oklab, ${cor} 30%, transparent)`,
              backgroundColor: `color-mix(in oklab, ${cor} 10%, transparent)`,
            }}
          >
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide" style={{ color: cor }}>
              <Zap className="h-3.5 w-3.5" /> No Pix
            </span>
            <span className="text-2xl font-extrabold" style={{ color: cor }}>{formatBRL(preco)}</span>
          </div>
          <div className="mt-1.5 min-h-[14px] text-[10px] text-muted-foreground">{p.parcelamento}</div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            {p.comprar_ativo && (
              <a
                href={checkoutHref || "#"}
                target="_blank"
                rel="noopener noreferrer"
                className={btnCls + " text-white shadow-sm"}
                style={{ backgroundColor: cor, borderColor: cor }}
              >
                <Zap className="h-4 w-4" /> {p.comprar_texto}
              </a>
            )}
            {p.demo_ativo && (
              <button
                type="button"
                onClick={abrirModal}
                className={btnCls + " shadow-sm"}
                style={{ backgroundColor: "#dc2626", borderColor: "#dc2626", color: "#ffffff" }}
              >
                <Globe className="h-4 w-4" /> {p.demo_texto}
              </button>
            )}
          </div>
        </div>
      </article>

      {/* Modal de vídeo - somente o vídeo com botão de fechar vermelho */}
      <Dialog open={videoModalAberto} onOpenChange={fecharVideoModal}>
        <DialogContent hideClose className="max-w-4xl overflow-hidden border-0 bg-black p-0">
          <DialogClose asChild>
            <button
              type="button"
              className="absolute right-3 top-3 z-50 flex h-10 w-10 items-center justify-center rounded-full bg-red-600 text-white shadow-lg transition hover:scale-105 hover:bg-red-700 focus:outline-none"
              aria-label="Fechar vídeo"
            >
              <X className="h-5 w-5" />
            </button>
          </DialogClose>
          <div className="relative aspect-video w-full overflow-hidden bg-black">
            {renderVideo()}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de detalhes do produto */}
      <Dialog open={modalAberto} onOpenChange={fecharModal}>
        <DialogContent hideClose className="max-h-[92vh] max-w-5xl overflow-y-auto p-0">
          <DialogClose asChild>
            <button
              type="button"
              className="absolute right-4 top-4 z-50 flex h-9 w-9 items-center justify-center rounded-full bg-foreground/70 text-background shadow-md transition hover:bg-foreground focus:outline-none"
              aria-label="Fechar"
            >
              <X className="h-5 w-5" />
            </button>
          </DialogClose>

          <div className="grid gap-0 md:grid-cols-2">
            <div className="relative min-h-[240px] w-full overflow-hidden bg-muted">
              {capaPopup ? (
                <img src={capaPopup} alt={p.titulo} className="h-full w-full object-cover" />

              ) : (
                <div className="flex h-full w-full items-center justify-center text-muted-foreground">Sem imagem</div>
              )}
            </div>

            <div className="space-y-4 p-6">
              <DialogHeader className="space-y-2 text-left">
                <DialogTitle className="text-2xl font-bold leading-tight">{p.titulo}</DialogTitle>
              </DialogHeader>

              {precoAntigo != null && precoAntigo > 0 && (
                <div className="text-sm font-bold text-destructive">
                  de <span className="line-through">{formatBRL(precoAntigo)}</span> por:
                </div>
              )}

              <div
                className="flex items-center justify-between gap-2 rounded-xl border px-5 py-4"
                style={{
                  borderColor: `color-mix(in oklab, ${cor} 30%, transparent)`,
                  backgroundColor: `color-mix(in oklab, ${cor} 10%, transparent)`,
                }}
              >
                <span className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wide" style={{ color: cor }}>
                  <Zap className="h-4 w-4" /> No Pix
                </span>
                <span className="text-3xl font-extrabold" style={{ color: cor }}>{formatBRL(preco)}</span>
              </div>
              {p.parcelamento && <div className="text-xs text-muted-foreground">{p.parcelamento}</div>}

              <div className="space-y-3">
                {p.comprar_ativo && (
                  <a
                    href={checkoutHref || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={btnCls + " text-white shadow-sm"}
                    style={{ backgroundColor: cor, borderColor: cor }}
                  >
                    <ShoppingCart className="h-4 w-4" /> {p.comprar_texto}
                  </a>
                )}
                {temVideo && (
                  <button
                    type="button"
                    onClick={() => {
                      fecharModal(false);
                      abrirVideoModal();
                    }}
                    className={btnCls + " border-transparent bg-[#d93a1f] text-white shadow-sm"}
                  >
                    <Play className="h-4 w-4" /> Ver vídeo
                  </button>
                )}
              </div>

              <ul className="space-y-4 rounded-xl border border-border p-4">
                <li className="flex items-start gap-3">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" style={{ color: cor }} />
                  <div>
                    <p className="text-sm font-bold">Compra Segura</p>
                    <p className="text-xs text-muted-foreground">Protegida por criptografia SSL</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <Clock className="mt-0.5 h-5 w-5 shrink-0" style={{ color: cor }} />
                  <div>
                    <p className="text-sm font-bold">Entrega automática</p>
                    <p className="text-xs text-muted-foreground">Receba imediatamente após pagamento</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <Award className="mt-0.5 h-5 w-5 shrink-0" style={{ color: cor }} />
                  <div>
                    <p className="text-sm font-bold">Produto de qualidade</p>
                    <p className="text-xs text-muted-foreground">Garantia de produto digital original</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-8 border-t border-border p-6 md:p-8">
            <section className="space-y-3">
              <h4 className="text-base font-bold">Descrição do produto</h4>
              <DialogDescription className="whitespace-pre-line text-sm leading-relaxed text-foreground">
                {p.descricao}
              </DialogDescription>

              <p className="pt-2 text-sm font-semibold">📦 Acesso Completo ao Código-Fonte + Videoaulas Inclusas</p>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Ao adquirir o produto, você receberá acesso ao código-fonte completo da aplicação, permitindo que utilize,
                modifique, personalize ou implemente o sistema da forma que desejar em seus próprios projetos.
              </p>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Além disso, você terá acesso a videoaulas detalhadas, onde é mostrado passo a passo como instalar, configurar
                e utilizar todas as funcionalidades do sistema, facilitando a implementação mesmo que você esteja começando.
              </p>

              <p className="pt-2 text-sm font-semibold">🎯 O que está incluso:</p>
              <ul className="space-y-1.5 text-sm text-muted-foreground">
                <li>✅ Código-fonte completo da aplicação</li>
                <li>✅ Liberdade para editar e personalizar</li>
                <li>✅ Videoaulas explicativas passo a passo</li>
              </ul>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Perfeito para desenvolvedores, empreendedores e profissionais que querem economizar tempo e acelerar seus
                projetos. 🚀
              </p>
            </section>

            <section className="space-y-3 border-t border-border pt-6">
              <h4 className="inline-flex items-center gap-2 text-sm font-bold">
                <AlertTriangle className="h-4 w-4 text-yellow-500" /> DISCLAIMER
              </h4>
              <p className="text-sm text-muted-foreground">Este produto não é um curso nem treinamento.</p>
              <p className="text-sm text-muted-foreground">
                Para utilizar a aplicação, é necessário possuir conhecimentos mínimos em informática, incluindo:
              </p>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>Configuração básica de sistemas</li>
                <li>Noções de hospedagem (VPS, domínio, DNS, etc.)</li>
                <li>Conceitos básicos de lógica de programação</li>
                <li>Familiaridade com ambientes de desenvolvimento</li>
              </ul>
              <p className="text-sm text-muted-foreground">Caso você não possua esse conhecimento, recomendamos:</p>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>👉 Contratar um desenvolvedor ou profissional da área</li>
                <li>👉 Utilizar ferramentas de vibe coding ou assistentes de IA para auxiliar na instalação, configuração e uso</li>
              </ul>
              <p className="text-sm text-muted-foreground">Não oferecemos suporte para ensino básico desses conceitos.</p>
            </section>

            {demoHref && (
              <a
                href={demoHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
              >
                <Globe className="h-4 w-4" /> Acessar demonstração externa
              </a>
            )}
          </div>
        </DialogContent>
      </Dialog>

    </>
  );
}
