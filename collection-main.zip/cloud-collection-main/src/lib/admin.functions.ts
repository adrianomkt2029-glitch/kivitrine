import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ADMIN_EMAILS = ["diano.baiano2015@gmail.com"];

/**
 * Concede o papel de administrador para os e-mails autorizados da loja.
 * Chamada logo após o login.
 */
export const ensureAdminRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const claims = context.claims as { email?: string } | null;
    const email = claims?.email?.toLowerCase();
    if (!email || !ADMIN_EMAILS.includes(email)) return { admin: false };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: context.userId, role: "admin" }, { onConflict: "user_id,role" });

    return { admin: true };
  });
