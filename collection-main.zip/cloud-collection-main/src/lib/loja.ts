import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Produto = Tables<"produtos">;

export type BannerConfig = {
  ativo: boolean;
  tipo: "youtube" | "mp4" | "iframe";
  video_url: string;
  mp4_url: string;
  capa_url: string;
  autoplay: boolean;
  controles: boolean;
  titulo: string;
  subtitulo: string;
  descricao: string;
  cor_fundo: string;
  cor_texto: string;
  posicao: "left" | "center" | "right";
};

export type AjudaConfig = {
  ativo: boolean;
  numero: string;
  mensagem: string;
  texto: string;
  icone: "whatsapp" | "chat" | "ajuda" | "telefone";
  cor_fundo: string;
  cor_texto: string;
  tamanho: "pequeno" | "medio" | "grande";
  posicao: "bottom-right" | "bottom-left";
};

export const bannerPadrao: BannerConfig = {
  ativo: true,
  tipo: "youtube",
  video_url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
  mp4_url: "",
  capa_url: "",
  autoplay: false,
  controles: true,
  titulo: "Códigos-fonte, automações e IA prontos para vender",
  subtitulo: "Lançamento",
  descricao:
    "Marketplace de produtos digitais premium para você lançar seu próprio negócio em minutos.",
  cor_fundo: "",
  cor_texto: "",
  posicao: "center",
};

export const ajudaPadrao: AjudaConfig = {
  ativo: true,
  numero: "5511999999999",
  mensagem: "Olá! 👋 Preciso de ajuda para escolher um produto da loja. Poderia me atender?",
  texto: "Precisa de Ajuda?",
  icone: "whatsapp",
  cor_fundo: "#25D366",
  cor_texto: "#ffffff",
  tamanho: "medio",
  posicao: "bottom-right",
};

export async function fetchConfig<T>(chave: string, padrao: T): Promise<T> {
  const { data } = await supabase.from("configuracoes").select("valor").eq("chave", chave).maybeSingle();
  if (!data?.valor) return padrao;
  return { ...padrao, ...(data.valor as object) } as T;
}

export async function salvarConfig(chave: string, valor: unknown) {
  const { error } = await supabase
    .from("configuracoes")
    .upsert({ chave, valor: valor as never }, { onConflict: "chave" });
  if (error) throw error;
}

export async function fetchProdutosPublicos() {
  const { data, error } = await supabase
    .from("produtos")
    .select("*")
    .eq("ativo", true)
    .order("ordem", { ascending: true });
  if (error) throw error;
  return (data ?? []) as Produto[];
}

export async function fetchProdutosAdmin() {
  const { data, error } = await supabase
    .from("produtos")
    .select("*")
    .order("ordem", { ascending: true });
  if (error) throw error;
  return (data ?? []) as Produto[];
}

/** Faz upload no bucket privado e devolve um link assinado de longa duração. */
export async function uploadImagem(file: File, pasta = "produtos") {
  const ext = file.name.split(".").pop() ?? "jpg";
  const path = `${pasta}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from("loja").upload(path, file, { upsert: true });
  if (error) throw error;
  const { data, error: signErr } = await supabase.storage
    .from("loja")
    .createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
  if (signErr) throw signErr;
  return data.signedUrl;
}

export function youtubeEmbed(url: string) {
  const limpo = (url || "").trim();
  if (!limpo) return "";
  // aceita link colado dentro de um <iframe src="...">
  const doIframe = limpo.match(/src=["']([^"']+)["']/i);
  const base = doIframe ? doIframe[1] : limpo;
  const match = base.match(/(?:youtu\.be\/|[?&]v=|embed\/|shorts\/|live\/)([\w-]{6,})/);
  return match ? `https://www.youtube.com/embed/${match[1]}` : base;
}

/** Junta parâmetros à URL respeitando query string já existente. */
export function comParams(url: string, params: Record<string, string | number>) {
  if (!url) return "";
  const query = Object.entries(params)
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join("&");
  if (!query) return url;
  return url + (url.includes("?") ? "&" : "?") + query;
}

/** Garante que links externos abram corretamente (adiciona https:// quando faltar). */
export function linkExterno(url?: string | null) {
  const limpo = (url || "").trim();
  if (!limpo) return "";
  if (/^(https?:|mailto:|tel:)/i.test(limpo)) return limpo;
  return `https://${limpo}`;
}

export function whatsappLink(numero?: string | null, mensagem?: string | null) {
  const num = (numero || "").replace(/\D/g, "");
  const texto = encodeURIComponent(mensagem || "Olá! Tenho interesse neste produto.");
  return `https://wa.me/${num}?text=${texto}`;
}

export function formatBRL(valor: number) {
  return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
