import agenda from "@/assets/product-agenda.jpg";
import crypto from "@/assets/product-trading.jpg";
import delivery from "@/assets/product-delivery.jpg";
import erp from "@/assets/product-erp.jpg";
import ia from "@/assets/product-ai.jpg";
import landing from "@/assets/product-landing.jpg";
import streaming from "@/assets/product-streaming.jpg";
import whatsapp from "@/assets/product-whatsapp.jpg";

/** Imagens locais usadas quando o produto não tem uma URL de imagem válida. */
const mapa: Array<{ chaves: string[]; src: string }> = [
  { chaves: ["agenda", "agendamento", "salao"], src: agenda },
  { chaves: ["crypto", "trader", "trading"], src: crypto },
  { chaves: ["delivery", "entrega"], src: delivery },
  { chaves: ["erp", "financeiro", "dashboard"], src: erp },
  { chaves: ["ia", "inteligencia", "boost", "lovable", "conteudo"], src: ia },
  { chaves: ["landing", "site", "page"], src: landing },
  { chaves: ["streaming", "video", "filmes"], src: streaming },
  { chaves: ["zap", "whatsapp", "bot", "atende"], src: whatsapp },
];

const semAcento = (t: string) =>
  t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

/** Devolve uma imagem utilizável: a do banco (se for URL real) ou uma local. */
export function imagemProduto(url: string | null | undefined, titulo: string): string {
  const limpo = (url || "").trim();
  if (/^(https?:|data:|blob:)/i.test(limpo)) return limpo;

  const texto = semAcento(`${titulo} ${limpo}`);
  const achado = mapa.find((m) => m.chaves.some((c) => texto.includes(c)));
  return achado?.src ?? landing;
}
