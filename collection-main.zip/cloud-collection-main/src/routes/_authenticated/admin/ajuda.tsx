import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ajudaPadrao, fetchConfig, salvarConfig, type AjudaConfig } from "@/lib/loja";
import { HelpButton } from "@/components/loja/HelpButton";

export const Route = createFileRoute("/_authenticated/admin/ajuda")({
  component: AjudaAdmin,
});

const inputCls = "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";

function Campo({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function AjudaAdmin() {
  const qc = useQueryClient();
  const { data } = useQuery<AjudaConfig>({ queryKey: ["cfg", "ajuda"], queryFn: () => fetchConfig("ajuda", ajudaPadrao) });
  const [cfg, setCfg] = useState<AjudaConfig>(ajudaPadrao);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    if (data) setCfg(data);
  }, [data]);

  const salvar = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(null);
    try {
      await salvarConfig("ajuda", cfg);
      void qc.invalidateQueries({ queryKey: ["cfg", "ajuda"] });
      setStatus("Botão salvo com sucesso!");
    } catch (err) {
      setStatus(err instanceof Error ? err.message : "Erro ao salvar");
    }
  };

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold">Botão Flutuante "Precisa de Ajuda?"</h1>
      <p className="mt-1 text-sm text-muted-foreground">Botão fixo que leva o cliente direto para o WhatsApp.</p>

      <form onSubmit={salvar} className="mt-6 space-y-4">
        <Campo label="Botão ativo">
          <select value={cfg.ativo ? "1" : "0"} onChange={(e) => setCfg({ ...cfg, ativo: e.target.value === "1" })} className={inputCls}>
            <option value="1">Ativado</option><option value="0">Desativado</option>
          </select>
        </Campo>
        <Campo label="Número do WhatsApp (com DDI)">
          <input value={cfg.numero} onChange={(e) => setCfg({ ...cfg, numero: e.target.value })} className={inputCls} placeholder="5511999999999" />
        </Campo>
        <Campo label="Mensagem automática">
          <textarea rows={3} value={cfg.mensagem} onChange={(e) => setCfg({ ...cfg, mensagem: e.target.value })} className={inputCls} />
        </Campo>
        <div className="grid gap-4 sm:grid-cols-2">
          <Campo label="Texto do botão"><input value={cfg.texto} onChange={(e) => setCfg({ ...cfg, texto: e.target.value })} className={inputCls} /></Campo>
          <Campo label="Ícone">
            <select value={cfg.icone} onChange={(e) => setCfg({ ...cfg, icone: e.target.value as AjudaConfig["icone"] })} className={inputCls}>
              <option value="whatsapp">WhatsApp</option><option value="chat">Chat</option><option value="ajuda">Ajuda</option><option value="telefone">Telefone</option>
            </select>
          </Campo>
          <Campo label="Cor de fundo"><input type="color" value={cfg.cor_fundo} onChange={(e) => setCfg({ ...cfg, cor_fundo: e.target.value })} className={inputCls + " h-10 p-1"} /></Campo>
          <Campo label="Cor do texto"><input type="color" value={cfg.cor_texto} onChange={(e) => setCfg({ ...cfg, cor_texto: e.target.value })} className={inputCls + " h-10 p-1"} /></Campo>
          <Campo label="Tamanho">
            <select value={cfg.tamanho} onChange={(e) => setCfg({ ...cfg, tamanho: e.target.value as AjudaConfig["tamanho"] })} className={inputCls}>
              <option value="pequeno">Pequeno</option><option value="medio">Médio</option><option value="grande">Grande</option>
            </select>
          </Campo>
          <Campo label="Posição">
            <select value={cfg.posicao} onChange={(e) => setCfg({ ...cfg, posicao: e.target.value as AjudaConfig["posicao"] })} className={inputCls}>
              <option value="bottom-right">Canto inferior direito</option><option value="bottom-left">Canto inferior esquerdo</option>
            </select>
          </Campo>
        </div>

        {status && <p className="rounded-md bg-primary/10 p-2 text-xs text-primary">{status}</p>}
        <button className="rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground">Salvar botão</button>
      </form>

      <HelpButton cfg={cfg} />
    </div>
  );
}
