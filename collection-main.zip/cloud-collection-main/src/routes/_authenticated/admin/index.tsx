import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Package, Star, XCircle, LayoutGrid } from "lucide-react";
import { fetchProdutosAdmin } from "@/lib/loja";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: Dashboard,
});

function Card({ label, valor, icon: Icon }: { label: string; valor: number; icon: typeof Package }) {
  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div className="mt-3 text-3xl font-bold">{valor}</div>
    </div>
  );
}

function Dashboard() {
  const { data = [], isLoading } = useQuery({ queryKey: ["produtos-admin"], queryFn: fetchProdutosAdmin });

  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="mt-1 text-sm text-muted-foreground">Visão geral da loja.</p>
      {isLoading ? (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-28 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <Card label="Total de produtos" valor={data.length} icon={Package} />
          <Card label="Produtos em Destaque" valor={data.filter((p) => p.secao === "destaque").length} icon={Star} />
          <Card label="Vitrine Completa" valor={data.filter((p) => p.secao !== "destaque").length} icon={LayoutGrid} />
          <Card label="Produtos ativos" valor={data.filter((p) => p.ativo).length} icon={CheckCircle2} />
          <Card label="Produtos inativos" valor={data.filter((p) => !p.ativo).length} icon={XCircle} />
        </div>
      )}
    </div>
  );
}
