import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Eye, EyeOff, Pencil, Plus, Search, Trash2, Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { fetchProdutosAdmin, uploadImagem, type Produto } from "@/lib/loja";

export const Route = createFileRoute("/_authenticated/admin/produtos")({
  component: ProdutosAdmin,
});

const PROVEDORES = ["Checkout Pro", "Mercado Pago", "Hotmart", "Kiwify", "Perfect Pay", "Monetizze", "personalizado"];
const POR_PAGINA = 10;

type Form = Partial<Produto> & { tagsTexto?: string };

const vazio: Form = {
  titulo: "",
  descricao: "",
  preco: 0,
  secao: "vitrine",
  ativo: true,
  ordem: 0,
  comprar_texto: "Comprar",
  comprar_cor: "#3b82f6",
  comprar_provedor: "personalizado",
  comprar_ativo: true,
  demo_texto: "Ver Demo",
  demo_cor: "#dc2626",
  demo_ativo: true,
  desconto: "",
  desconto_cor: "#f97316",
  desconto_ativo: true,
  tagsTexto: "",
};

function Campo({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

const inputCls = "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary";

function ProdutosAdmin() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({ queryKey: ["produtos-admin"], queryFn: fetchProdutosAdmin });
  const [busca, setBusca] = useState("");
  const [secao, setSecao] = useState<"todos" | "destaque" | "vitrine">("todos");
  const [pagina, setPagina] = useState(1);
  const [form, setForm] = useState<Form | null>(null);
  const [enviando, setEnviando] = useState<null | "imagem" | "video" | "popup">(null);
  const [erro, setErro] = useState<string | null>(null);

  const invalidar = () => {
    void qc.invalidateQueries({ queryKey: ["produtos-admin"] });
    void qc.invalidateQueries({ queryKey: ["produtos-publicos"] });
  };

  const salvar = useMutation({
    mutationFn: async (f: Form) => {
      const { tagsTexto, id, created_at, updated_at, ...resto } = f;
      const payload = {
        ...resto,
        titulo: (resto.titulo ?? "").trim(),
        descricao: resto.descricao ?? "",
        imagem_url: resto.imagem_url?.trim() || null,
        video_url: resto.video_url?.trim() || null,
        popup_video_url: resto.popup_video_url?.trim() || null,
        popup_video_tipo: resto.popup_video_tipo || "auto",
        popup_imagem_url: resto.popup_imagem_url?.trim() || null,
        demo_url: resto.demo_url?.trim() || null,
        checkout_url: resto.checkout_url?.trim() || null,
        whatsapp_url: resto.whatsapp_url?.trim() || null,
        secao: resto.secao ?? "vitrine",
        destaque: (resto.secao ?? "vitrine") === "destaque",
        preco: Number(resto.preco ?? 0),
        ordem: Number(resto.ordem ?? 0),
        preco_antigo: resto.preco_antigo != null && `${resto.preco_antigo}` !== "" ? Number(resto.preco_antigo) : null,
        tags: (tagsTexto ?? "").split(",").map((t) => t.trim()).filter(Boolean),
      };
      if (!payload.titulo) throw new Error("Informe o nome do produto.");
      if (id) {
        const { error } = await supabase.from("produtos").update(payload).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("produtos").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      setForm(null);
      invalidar();
    },
    onError: (e: unknown) => setErro(e instanceof Error ? e.message : "Erro ao salvar"),
  });

  const excluir = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("produtos").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
    onError: (e: unknown) => setErro(e instanceof Error ? e.message : "Erro ao excluir"),
  });

  const atualizar = useMutation({
    mutationFn: async ({ id, patch }: { id: string; patch: Partial<Produto> }) => {
      const { error } = await supabase.from("produtos").update(patch).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
    onError: (e: unknown) => setErro(e instanceof Error ? e.message : "Erro ao atualizar"),
  });

  const filtrados = useMemo(() => {
    const q = busca.trim().toLowerCase();
    return data.filter((p) => {
      const naSecao = secao === "todos" || (secao === "destaque" ? p.secao === "destaque" : p.secao !== "destaque");
      const naBusca = !q || p.titulo.toLowerCase().includes(q) || p.tags?.some((t) => t.toLowerCase().includes(q));
      return naSecao && naBusca;
    });
  }, [data, busca, secao]);

  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / POR_PAGINA));
  const paginaAtual = Math.min(pagina, totalPaginas);
  const visiveis = filtrados.slice((paginaAtual - 1) * POR_PAGINA, paginaAtual * POR_PAGINA);

  const abrirEdicao = (p: Produto) => {
    setErro(null);
    setForm({ ...p, tagsTexto: (p.tags ?? []).join(", ") });
  };

  const LIMITE_MB = { imagem: 10, video: 50, popup: 10 } as const;

  const enviarArquivo = async (
    file: File,
    tipo: "imagem" | "video" | "popup",
  ) => {
    setErro(null);
    const esperado = tipo === "video" ? "video/" : "image/";
    if (!file.type.startsWith(esperado)) {
      setErro(tipo === "video" ? "Envie um arquivo de vídeo (MP4, WebM ou OGG)." : "Envie um arquivo de imagem (JPG, PNG ou WebP).");
      return;
    }
    const limite = LIMITE_MB[tipo];
    if (file.size > limite * 1024 * 1024) {
      setErro(`Arquivo muito grande (${(file.size / 1024 / 1024).toFixed(1)} MB). O limite é ${limite} MB.`);
      return;
    }
    setEnviando(tipo);
    try {
      const pasta = tipo === "imagem" ? "produtos" : tipo === "video" ? "videos" : "popup";
      const campo = tipo === "imagem" ? "imagem_url" : tipo === "video" ? "video_url" : "popup_imagem_url";
      const url = await uploadImagem(file, pasta);
      setForm((f) => (f ? { ...f, [campo]: url } : f));
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Falha no upload do arquivo");
    } finally {
      setEnviando(null);
    }
  };



  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Produtos</h1>
          <p className="mt-1 text-sm text-muted-foreground">Gerencie os produtos em Destaque e da Vitrine Completa.</p>
        </div>
        <button
          onClick={() => {
            setErro(null);
            setForm({ ...vazio });
          }}
          className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
        >
          <Plus className="h-4 w-4" /> Novo produto
        </button>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={busca}
            onChange={(e) => {
              setBusca(e.target.value);
              setPagina(1);
            }}
            placeholder="Pesquisar por nome ou tag..."
            className={inputCls + " pl-9"}
          />
        </div>
        <select value={secao} onChange={(e) => setSecao(e.target.value as typeof secao)} className={inputCls + " w-auto"}>
          <option value="todos">Todas as seções</option>
          <option value="destaque">Produtos em Destaque</option>
          <option value="vitrine">Vitrine Completa</option>
        </select>
      </div>

      {erro && !form && (
        <p className="mt-4 rounded-md bg-destructive/10 p-3 text-xs text-destructive">{erro}</p>
      )}



      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Produto</th>
              <th className="px-4 py-3">Seção</th>
              <th className="px-4 py-3">Valor</th>
              <th className="px-4 py-3">Ordem</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">Carregando...</td>
              </tr>
            )}
            {!isLoading && visiveis.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">Nenhum produto encontrado.</td>
              </tr>
            )}
            {visiveis.map((p) => (
              <tr key={p.id} className="border-t border-border">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {p.imagem_url ? (
                      <img src={p.imagem_url} alt={p.titulo} className="h-10 w-14 rounded object-cover" />
                    ) : (
                      <div className="h-10 w-14 rounded bg-muted" />
                    )}
                    <div>
                      <div className="font-medium">{p.titulo}</div>
                      <div className="text-xs text-muted-foreground">{(p.tags ?? []).join(", ")}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">{p.secao === "destaque" ? "Destaque" : "Vitrine"}</td>
                <td className="px-4 py-3">R$ {Number(p.preco).toFixed(2)}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button onClick={() => atualizar.mutate({ id: p.id, patch: { ordem: p.ordem - 1 } })} className="rounded p-1 hover:bg-muted" aria-label="Subir">
                      <ArrowUp className="h-4 w-4" />
                    </button>
                    <span className="w-6 text-center">{p.ordem}</span>
                    <button onClick={() => atualizar.mutate({ id: p.id, patch: { ordem: p.ordem + 1 } })} className="rounded p-1 hover:bg-muted" aria-label="Descer">
                      <ArrowDown className="h-4 w-4" />
                    </button>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => atualizar.mutate({ id: p.id, patch: { ativo: !p.ativo } })}
                    className={
                      "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium " +
                      (p.ativo ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground")
                    }
                  >
                    {p.ativo ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                    {p.ativo ? "Ativo" : "Inativo"}
                  </button>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => abrirEdicao(p)} className="rounded p-2 hover:bg-muted" aria-label="Editar">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Excluir "${p.titulo}"?`)) excluir.mutate(p.id);
                      }}
                      className="rounded p-2 text-destructive hover:bg-destructive/10"
                      aria-label="Excluir"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPaginas > 1 && (
        <div className="mt-6 flex justify-center gap-2">
          {Array.from({ length: totalPaginas }).map((_, i) => (
            <button
              key={i}
              onClick={() => setPagina(i + 1)}
              className={
                "h-9 w-9 rounded-md border text-sm " +
                (paginaAtual === i + 1 ? "border-transparent bg-primary text-primary-foreground" : "border-border hover:bg-muted")
              }
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}

      {form && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/60 p-4">
          <div className="my-8 w-full max-w-3xl rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold">{form.id ? "Editar produto" : "Novo produto"}</h2>
              <button onClick={() => setForm(null)} className="rounded p-2 hover:bg-muted" aria-label="Fechar">
                <X className="h-4 w-4" />
              </button>
            </div>

            <form
              className="mt-5 space-y-6"
              onSubmit={(e) => {
                e.preventDefault();
                setErro(null);
                salvar.mutate(form);
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Campo label="Nome do produto">
                  <input required value={form.titulo ?? ""} onChange={(e) => setForm({ ...form, titulo: e.target.value })} className={inputCls} />
                </Campo>
                <Campo label="Seção">
                  <select value={form.secao ?? "vitrine"} onChange={(e) => setForm({ ...form, secao: e.target.value, destaque: e.target.value === "destaque" })} className={inputCls}>
                    <option value="destaque">Produtos em Destaque</option>
                    <option value="vitrine">Vitrine Completa</option>
                  </select>
                </Campo>
                <Campo label="Tags (separadas por vírgula)">
                  <input value={form.tagsTexto ?? ""} onChange={(e) => setForm({ ...form, tagsTexto: e.target.value })} className={inputCls} placeholder="IA, Sites, Automação" />
                </Campo>
                <Campo label="Selo (ex: NOVO)">
                  <input value={form.selo ?? ""} onChange={(e) => setForm({ ...form, selo: e.target.value })} className={inputCls} />
                </Campo>
                <Campo label="Valor (R$)">
                  <input type="number" step="0.01" value={String(form.preco ?? 0)} onChange={(e) => setForm({ ...form, preco: Number(e.target.value) })} className={inputCls} />
                </Campo>
                <Campo label="Valor antigo (R$)">
                  <input type="number" step="0.01" value={form.preco_antigo != null ? String(form.preco_antigo) : ""} onChange={(e) => setForm({ ...form, preco_antigo: e.target.value === "" ? null : Number(e.target.value) })} className={inputCls} />
                </Campo>
                <Campo label="Parcelamento">
                  <input value={form.parcelamento ?? ""} onChange={(e) => setForm({ ...form, parcelamento: e.target.value })} className={inputCls} placeholder="12x de R$ 29,70" />
                </Campo>
                <Campo label="Ordem">
                  <input type="number" value={String(form.ordem ?? 0)} onChange={(e) => setForm({ ...form, ordem: Number(e.target.value) })} className={inputCls} />
                </Campo>
              </div>

              <Campo label="Descrição">
                <textarea rows={3} value={form.descricao ?? ""} onChange={(e) => setForm({ ...form, descricao: e.target.value })} className={inputCls} />
              </Campo>

              <div className="grid gap-4 sm:grid-cols-2">
                <Campo label="Imagem de capa do card (URL)">
                  <input value={form.imagem_url ?? ""} onChange={(e) => setForm({ ...form, imagem_url: e.target.value })} className={inputCls} placeholder="https://..." />
                </Campo>
                <div>
                  <span className="mb-1 block text-xs font-medium text-muted-foreground">Upload da imagem de capa</span>
                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted">
                    <Upload className="h-4 w-4" /> {enviando === "imagem" ? "Enviando..." : "Escolher arquivo"}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void enviarArquivo(f, "imagem");
                      }}
                    />
                  </label>
                  {form.imagem_url && <img src={form.imagem_url} alt="Prévia" className="mt-2 h-20 w-32 rounded object-cover" />}
                </div>
              </div>

              <fieldset className="rounded-lg border border-border p-4">
                <legend className="px-1 text-sm font-semibold">Vídeo do card (abre ao clicar na imagem)</legend>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Campo label="Link do vídeo (YouTube ou MP4)">
                    <input
                      value={form.video_url ?? ""}
                      onChange={(e) => setForm({ ...form, video_url: e.target.value })}
                      className={inputCls}
                      placeholder="https://youtu.be/... ou https://.../video.mp4"
                    />
                  </Campo>
                  <div>
                    <span className="mb-1 block text-xs font-medium text-muted-foreground">Upload de vídeo MP4</span>
                    <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted">
                      <Upload className="h-4 w-4" /> {enviando === "video" ? "Enviando..." : "Escolher arquivo"}
                      <input
                        type="file"
                        accept="video/mp4,video/webm,video/ogg"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) void enviarArquivo(f, "video");
                        }}
                      />
                    </label>
                    {form.video_url && (
                      <p className="mt-2 break-all text-[11px] text-muted-foreground">{form.video_url}</p>
                    )}
                  </div>
                </div>
                <p className="mt-2 text-[11px] text-muted-foreground">
                  Sem vídeo, o selo "Clique Aqui" abre o link de demonstração.
                </p>
              </fieldset>

              <fieldset className="rounded-lg border border-border p-4">
                <legend className="px-1 text-sm font-semibold">Popup "Ver Demo"</legend>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Campo label="Link do vídeo do popup (YouTube, MP4 ou iframe)">
                    <input
                      value={form.popup_video_url ?? ""}
                      onChange={(e) => setForm({ ...form, popup_video_url: e.target.value })}
                      className={inputCls}
                      placeholder="Deixe vazio para usar o vídeo do card"
                    />
                  </Campo>
                  <Campo label="Tipo do vídeo">
                    <select
                      value={form.popup_video_tipo ?? "auto"}
                      onChange={(e) => setForm({ ...form, popup_video_tipo: e.target.value })}
                      className={inputCls}
                    >
                      <option value="auto">Detectar automaticamente</option>
                      <option value="youtube">YouTube</option>
                      <option value="mp4">MP4 / vídeo</option>
                      <option value="iframe">Iframe / outro</option>
                    </select>
                  </Campo>
                  <Campo label="Imagem de capa do popup (URL)">
                    <input
                      value={form.popup_imagem_url ?? ""}
                      onChange={(e) => setForm({ ...form, popup_imagem_url: e.target.value })}
                      className={inputCls}
                      placeholder="Deixe vazio para usar a capa do card"
                    />
                  </Campo>
                  <div>
                    <span className="mb-1 block text-xs font-medium text-muted-foreground">Upload da capa do popup</span>
                    <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted">
                      <Upload className="h-4 w-4" /> {enviando === "popup" ? "Enviando..." : "Escolher arquivo"}
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) void enviarArquivo(f, "popup");
                        }}
                      />
                    </label>
                    {form.popup_imagem_url && (
                      <img src={form.popup_imagem_url} alt="Prévia" className="mt-2 h-20 w-32 rounded object-cover" />
                    )}
                  </div>
                </div>
                <p className="mt-2 text-[11px] text-muted-foreground">
                  Estes campos alimentam automaticamente o popup aberto pelo botão "Ver Demo".
                </p>
              </fieldset>



              <fieldset className="rounded-lg border border-border p-4">
                <legend className="px-2 text-sm font-semibold">Botão Comprar</legend>
                <div className="grid gap-4 sm:grid-cols-4">
                  <Campo label="Texto"><input value={form.comprar_texto ?? ""} onChange={(e) => setForm({ ...form, comprar_texto: e.target.value })} className={inputCls} /></Campo>
                  <Campo label="Cor"><input type="color" value={form.comprar_cor ?? "#3b82f6"} onChange={(e) => setForm({ ...form, comprar_cor: e.target.value })} className={inputCls + " h-10 p-1"} /></Campo>
                  <Campo label="Plataforma">
                    <select value={form.comprar_provedor ?? "personalizado"} onChange={(e) => setForm({ ...form, comprar_provedor: e.target.value })} className={inputCls}>
                      {PROVEDORES.map((p) => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </Campo>
                  <Campo label="Ativo">
                    <select value={form.comprar_ativo ? "1" : "0"} onChange={(e) => setForm({ ...form, comprar_ativo: e.target.value === "1" })} className={inputCls}>
                      <option value="1">Sim</option><option value="0">Não</option>
                    </select>
                  </Campo>
                </div>
                <Campo label="Link de checkout"><input value={form.checkout_url ?? ""} onChange={(e) => setForm({ ...form, checkout_url: e.target.value })} className={inputCls} placeholder="https://..." /></Campo>
              </fieldset>

              <fieldset className="rounded-lg border border-border p-4">
                <legend className="px-2 text-sm font-semibold">Botão Ver Demonstração</legend>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Campo label="Texto"><input value={form.demo_texto ?? ""} onChange={(e) => setForm({ ...form, demo_texto: e.target.value })} className={inputCls} /></Campo>
                  <Campo label="Cor"><input type="color" value={form.demo_cor ?? "#dc2626"} onChange={(e) => setForm({ ...form, demo_cor: e.target.value })} className={inputCls + " h-10 p-1"} /></Campo>
                  <Campo label="Ativo">
                    <select value={form.demo_ativo ? "1" : "0"} onChange={(e) => setForm({ ...form, demo_ativo: e.target.value === "1" })} className={inputCls}>
                      <option value="1">Sim</option><option value="0">Não</option>
                    </select>
                  </Campo>
                </div>
                <Campo label="Link (site, landing page ou página de vendas)"><input value={form.demo_url ?? ""} onChange={(e) => setForm({ ...form, demo_url: e.target.value })} className={inputCls} /></Campo>
              </fieldset>

              <fieldset className="rounded-lg border border-border p-4">
                <legend className="px-2 text-sm font-semibold">Selo de desconto na imagem</legend>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Campo label="Texto (ex: 30% OFF)"><input value={form.desconto ?? ""} onChange={(e) => setForm({ ...form, desconto: e.target.value })} className={inputCls} /></Campo>
                  <Campo label="Cor"><input type="color" value={form.desconto_cor ?? "#f97316"} onChange={(e) => setForm({ ...form, desconto_cor: e.target.value })} className={inputCls + " h-10 p-1"} /></Campo>
                  <Campo label="Ativo">
                    <select value={form.desconto_ativo ? "1" : "0"} onChange={(e) => setForm({ ...form, desconto_ativo: e.target.value === "1" })} className={inputCls}>
                      <option value="1">Sim</option><option value="0">Não</option>
                    </select>
                  </Campo>
                </div>
              </fieldset>

              <Campo label="Produto visível na loja">
                <select value={form.ativo ? "1" : "0"} onChange={(e) => setForm({ ...form, ativo: e.target.value === "1" })} className={inputCls}>
                  <option value="1">Mostrar</option><option value="0">Ocultar</option>
                </select>
              </Campo>

              {erro && <p className="rounded-md bg-destructive/10 p-2 text-xs text-destructive">{erro}</p>}

              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setForm(null)} className="rounded-md border border-border px-4 py-2 text-sm">Cancelar</button>
                <button type="submit" disabled={salvar.isPending || !!enviando} className="rounded-md bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60">
                  {enviando ? "Aguarde o upload..." : salvar.isPending ? "Salvando..." : "Salvar produto"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
