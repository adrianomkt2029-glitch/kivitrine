import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ensureAdminRole } from "@/lib/admin.functions";
import { Lock, Mail, LogIn } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Login do Painel — AP SISTEMAS" },
      { name: "description", content: "Acesse o painel administrativo da loja AP SISTEMAS." },
      { property: "og:title", content: "Login do Painel — AP SISTEMAS" },
      { property: "og:description", content: "Acesse o painel administrativo da loja." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [modo, setModo] = useState<"login" | "cadastro" | "recuperar">("login");
  const [msg, setMsg] = useState<string | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session) void navigate({ to: "/admin" });
    });
  }, [navigate]);

  const submeter = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro(null);
    setMsg(null);
    setCarregando(true);
    try {
      if (modo === "recuperar") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setMsg("Enviamos um e-mail com o link para redefinir sua senha.");
        return;
      }
      if (modo === "cadastro") {
        const { error } = await supabase.auth.signUp({
          email,
          password: senha,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
      }
      const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
      if (error) throw error;
      await ensureAdminRole();
      await navigate({ to: "/admin" });
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Não foi possível entrar.");
    } finally {
      setCarregando(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-lg">
        <h1 className="text-2xl font-bold">Painel Administrativo</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {modo === "recuperar" ? "Informe seu e-mail para recuperar a senha." : "Entre para gerenciar a loja."}
        </p>

        <form onSubmit={submeter} className="mt-6 space-y-4">
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-muted-foreground">E-mail</span>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-border bg-background py-2 pl-9 pr-3 text-sm outline-none focus:border-primary"
                placeholder="seu@email.com"
              />
            </div>
          </label>

          {modo !== "recuperar" && (
            <label className="block">
              <span className="mb-1 block text-xs font-medium text-muted-foreground">Senha</span>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="w-full rounded-md border border-border bg-background py-2 pl-9 pr-3 text-sm outline-none focus:border-primary"
                  placeholder="••••••••"
                />
              </div>
            </label>
          )}

          {erro && <p className="rounded-md bg-destructive/10 p-2 text-xs text-destructive">{erro}</p>}
          {msg && <p className="rounded-md bg-primary/10 p-2 text-xs text-primary">{msg}</p>}

          <button
            type="submit"
            disabled={carregando}
            className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-60"
          >
            <LogIn className="h-4 w-4" />
            {carregando ? "Aguarde..." : modo === "cadastro" ? "Criar conta e entrar" : modo === "recuperar" ? "Enviar link" : "Entrar"}
          </button>
        </form>

        <div className="mt-5 flex flex-wrap justify-between gap-2 text-xs text-muted-foreground">
          <button onClick={() => setModo(modo === "cadastro" ? "login" : "cadastro")} className="hover:text-primary">
            {modo === "cadastro" ? "Já tenho conta" : "Criar conta de administrador"}
          </button>
          <button onClick={() => setModo("recuperar")} className="hover:text-primary">
            Esqueci minha senha
          </button>
        </div>
      </div>
    </div>
  );
}
