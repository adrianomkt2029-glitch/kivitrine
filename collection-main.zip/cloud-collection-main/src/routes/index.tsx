import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check, ChevronDown, Code2, Headphones, Moon, Search, Shield, Star, Sun, Tag, Zap, LayoutDashboard } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { VideoBanner } from "@/components/loja/VideoBanner";
import { HelpButton } from "@/components/loja/HelpButton";
import { ProductCard } from "@/components/loja/ProductCard";
import {
  ajudaPadrao,
  bannerPadrao,
  fetchConfig,
  fetchProdutosPublicos,
  type AjudaConfig,
  type BannerConfig,
} from "@/lib/loja";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Loja Vitrine — Códigos-fonte, Automações e IA" },
      {
        name: "description",
        content:
          "Marketplace de produtos digitais premium, automações e ferramentas de IA para você lançar seu próprio negócio digital.",
      },
      { property: "og:title", content: "Loja Vitrine — Códigos-fonte, Automações e IA" },
      { property: "og:description", content: "Marketplace de produtos digitais premium, automações e ferramentas de IA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Code2, title: "Código-fonte completo", desc: "Você recebe tudo: front, back e documentação." },
  { icon: Zap, title: "Pronto para uso", desc: "Sistemas testados e prontos para deploy imediato." },
  { icon: Shield, title: "Compra 100% segura", desc: "Pagamento protegido e garantia de 7 dias." },
  { icon: Headphones, title: "Suporte dedicado", desc: "Time pronto para ajudar via WhatsApp e Discord." },
];

const faqs = [
  { q: "Como recebo meu produto após a compra?", a: "Logo após a confirmação do pagamento você recebe por e-mail o acesso à área de membros com download e documentação." },
  { q: "Posso revender o sistema para meus clientes?", a: "Sim. Todos os produtos possuem licença para uso comercial e revenda ilimitada." },
  { q: "Existe garantia?", a: "Sim, oferecemos 7 dias de garantia incondicional." },
  { q: "Os códigos recebem atualizações?", a: "Sim. Atualizações gratuitas na sua área de membros." },
  { q: "Tem suporte técnico?", a: "Sim, suporte via WhatsApp e Discord." },
  { q: "Quais formas de pagamento aceitas?", a: "Pix, cartão de crédito em até 12x e boleto bancário." },
];

const POR_PAGINA = 12;

function Index() {
  const [query, setQuery] = useState("");
  const [tagAtiva, setTagAtiva] = useState("Todos");
  const [pagina, setPagina] = useState(1);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [mounted, setMounted] = useState(false);

  const produtos = useQuery({ queryKey: ["produtos-publicos"], queryFn: fetchProdutosPublicos });
  const banner = useQuery<BannerConfig>({ queryKey: ["cfg", "banner"], queryFn: () => fetchConfig("banner", bannerPadrao) });
  const ajuda = useQuery<AjudaConfig>({ queryKey: ["cfg", "ajuda"], queryFn: () => fetchConfig("ajuda", ajudaPadrao) });

  useEffect(() => {
    setMounted(true);
    const saved = window.localStorage.getItem("theme");
    setTheme(saved === "light" || saved === "dark" ? saved : "light");
  }, []);

  useEffect(() => {
    if (!mounted) return;
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem("theme", theme);
  }, [theme, mounted]);

  const lista = produtos.data ?? [];
  const destaques = lista.filter((p) => p.secao === "destaque");
  const vitrine = lista.filter((p) => p.secao !== "destaque");

  const tags = useMemo(() => {
    const set = new Set<string>();
    vitrine.forEach((p) => p.tags?.forEach((t) => set.add(t)));
    return ["Todos", ...Array.from(set)];
  }, [vitrine]);

  const filtrados = useMemo(() => {
    const q = query.trim().toLowerCase();
    return vitrine.filter((p) => {
      const naTag = tagAtiva === "Todos" || p.tags?.includes(tagAtiva);
      const naBusca = !q || p.titulo.toLowerCase().includes(q) || p.tags?.some((t) => t.toLowerCase().includes(q));
      return naTag && naBusca;
    });
  }, [vitrine, query, tagAtiva]);

  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / POR_PAGINA));
  const paginaAtual = Math.min(pagina, totalPaginas);
  const visiveis = filtrados.slice((paginaAtual - 1) * POR_PAGINA, paginaAtual * POR_PAGINA);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <a href="/" className="flex items-center gap-1 text-2xl font-bold tracking-tight">
            <span className="text-primary">Loja</span>
            <span>Vitrine</span>
          </a>
          <div className="flex items-center gap-3">
            <button onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} className="rounded-full p-2 hover:bg-muted" aria-label="Alternar tema">
              {mounted && theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <Link to="/admin" className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium hover:bg-muted">
              <LayoutDashboard className="h-4 w-4" /> Painel
            </Link>
          </div>
        </div>
      </header>

      {banner.data && <VideoBanner cfg={banner.data} />}

      {destaques.length > 0 && (
        <section id="destaques" className="mx-auto max-w-7xl px-6 pt-14">
          <div className="mb-6 flex items-center gap-3">
            <Star className="h-6 w-6" style={{ color: "#f97316", fill: "#f97316" }} />
            <h2 className="text-2xl font-bold tracking-tight md:text-3xl">Produtos em Destaque</h2>
          </div>
          <div className="grid items-stretch gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {destaques.map((p) => (
              <ProductCard key={p.id} p={p} />
            ))}
          </div>
        </section>
      )}

      <section id="catalogo" className="mx-auto max-w-7xl px-6 py-16">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <Tag className="h-6 w-6" style={{ color: "#f97316" }} />
            <h2 className="text-2xl font-bold tracking-tight md:text-3xl">Vitrine Completa</h2>
          </div>
          <div className="relative w-full md:w-80">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPagina(1);
              }}
              placeholder="Buscar por nome ou tag..."
              className="w-full rounded-md border border-border bg-card py-2 pl-9 pr-3 text-sm outline-none focus:border-primary"
            />
          </div>
        </div>

        {tags.length > 1 && (
          <div className="mb-8 flex flex-wrap gap-2">
            {tags.map((t) => (
              <button
                key={t}
                onClick={() => {
                  setTagAtiva(t);
                  setPagina(1);
                }}
                className={
                  "rounded-full border px-4 py-1.5 text-sm font-medium transition " +
                  (tagAtiva === t ? "border-transparent bg-primary text-primary-foreground" : "border-border bg-card hover:bg-muted")
                }
              >
                {t}
              </button>
            ))}
          </div>
        )}

        {produtos.isLoading ? (
          <div className="grid items-stretch gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-72 animate-pulse rounded-xl bg-muted" />
            ))}
          </div>
        ) : visiveis.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground">
            Nenhum produto encontrado.
          </div>
        ) : (
          <>
            <div className="grid items-stretch gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {visiveis.map((p) => (
                <ProductCard key={p.id} p={p} />
              ))}
            </div>
            {totalPaginas > 1 && (
              <div className="mt-10 flex items-center justify-center gap-2">
                {Array.from({ length: totalPaginas }).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setPagina(i + 1)}
                    className={
                      "h-9 w-9 rounded-md border text-sm font-medium transition " +
                      (paginaAtual === i + 1 ? "border-transparent bg-primary text-primary-foreground" : "border-border bg-card hover:bg-muted")
                    }
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </section>

      <section id="sobre" className="border-t border-border bg-secondary/30">
        <div className="mx-auto max-w-7xl px-6 py-16">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight">Por que comprar com a gente</h2>
            <p className="mt-3 text-muted-foreground">Tudo o que você precisa para sair do zero ao lançamento.</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div key={f.title} className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-card)]">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="font-bold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-3xl px-6 py-20">
        <div className="mb-10 text-center">
          <h2 className="text-3xl font-bold tracking-tight">Perguntas Frequentes</h2>
        </div>
        <div className="space-y-3">
          {faqs.map((f, i) => {
            const open = openFaq === i;
            return (
              <div key={f.q} className="overflow-hidden rounded-xl border border-border bg-card">
                <button onClick={() => setOpenFaq(open ? null : i)} className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-semibold hover:bg-muted/50">
                  <span className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary" /> {f.q}
                  </span>
                  <ChevronDown className={"h-5 w-5 shrink-0 transition " + (open ? "rotate-180" : "")} />
                </button>
                {open && <div className="px-5 pb-5 text-sm text-muted-foreground">{f.a}</div>}
              </div>
            );
          })}
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 text-sm text-muted-foreground md:flex-row">
          <p>© 2026 Loja Vitrine — Todos os direitos reservados.</p>
          <div className="flex gap-6">
            <a href="#sobre" className="hover:text-foreground">Sobre</a>
            <a href="#faq" className="hover:text-foreground">FAQ</a>
            <Link to="/admin" className="hover:text-foreground">Painel</Link>
          </div>
        </div>
      </footer>

      {ajuda.data && <HelpButton cfg={ajuda.data} />}
    </div>
  );
}
