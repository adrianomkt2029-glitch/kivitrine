DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin', 'user');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role       public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL    ON public.user_roles TO service_role;

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT  EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT  USAGE  ON TYPE public.app_role TO authenticated, service_role;

REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;

CREATE TABLE IF NOT EXISTS public.categorias (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome       text NOT NULL,
  slug       text NOT NULL UNIQUE,
  ordem      integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT                         ON public.categorias TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categorias TO authenticated;
GRANT ALL                            ON public.categorias TO service_role;

ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Categorias sao publicas"
  ON public.categorias FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Admins gerenciam categorias"
  ON public.categorias FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER categorias_updated_at
  BEFORE UPDATE ON public.categorias
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.produtos (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo           text NOT NULL,
  descricao        text NOT NULL DEFAULT '',
  imagem_url       text,
  preco            numeric(10,2) NOT NULL DEFAULT 0,
  preco_antigo     numeric(10,2),
  parcelamento     text,
  selo             text,
  desconto         text,
  desconto_cor     text NOT NULL DEFAULT '#f97316',
  desconto_ativo   boolean NOT NULL DEFAULT true,
  categoria_id     uuid REFERENCES public.categorias(id) ON DELETE SET NULL,
  checkout_url     text,
  video_url        text,
  demo_url         text,
  whatsapp_url     text,
  popup_video_url  text,
  popup_video_tipo text NOT NULL DEFAULT 'auto',
  popup_imagem_url text,
  secao            text NOT NULL DEFAULT 'vitrine',
  tags             text[] NOT NULL DEFAULT '{}',
  comprar_texto    text NOT NULL DEFAULT 'Comprar',
  comprar_cor      text NOT NULL DEFAULT '#3b82f6',
  comprar_provedor text NOT NULL DEFAULT 'personalizado',
  comprar_ativo    boolean NOT NULL DEFAULT true,
  demo_texto       text NOT NULL DEFAULT 'Ver Demo',
  demo_cor         text NOT NULL DEFAULT '#dc2626',
  demo_ativo       boolean NOT NULL DEFAULT true,
  destaque         boolean NOT NULL DEFAULT false,
  ativo            boolean NOT NULL DEFAULT true,
  ordem            integer NOT NULL DEFAULT 0,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT                         ON public.produtos TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.produtos TO authenticated;
GRANT ALL                            ON public.produtos TO service_role;

ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Produtos ativos sao publicos"
  ON public.produtos FOR SELECT TO anon, authenticated USING (ativo = true);

CREATE POLICY "Admins veem todos os produtos"
  ON public.produtos FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins gerenciam produtos"
  ON public.produtos FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER produtos_updated_at
  BEFORE UPDATE ON public.produtos
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS produtos_categoria_idx ON public.produtos(categoria_id);
CREATE INDEX IF NOT EXISTS produtos_secao_idx     ON public.produtos(secao, ordem);

CREATE TABLE IF NOT EXISTS public.configuracoes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chave      text NOT NULL UNIQUE,
  valor      jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT                         ON public.configuracoes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.configuracoes TO authenticated;
GRANT ALL                            ON public.configuracoes TO service_role;

ALTER TABLE public.configuracoes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Configuracoes sao publicas"
  ON public.configuracoes FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Admins gerenciam configuracoes"
  ON public.configuracoes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER configuracoes_updated_at
  BEFORE UPDATE ON public.configuracoes
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE IF NOT EXISTS public.leads (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome       text NOT NULL,
  email      text,
  telefone   text,
  produto_id uuid REFERENCES public.produtos(id) ON DELETE SET NULL,
  mensagem   text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT         ON public.leads TO anon;
GRANT SELECT, INSERT ON public.leads TO authenticated;
GRANT ALL            ON public.leads TO service_role;

ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Qualquer um pode enviar contato"
  ON public.leads FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Admins veem leads"
  ON public.leads FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.categorias (id, nome, slug, ordem) VALUES
 ('e49b8295-c00e-4d87-87b7-a7c12558f719'::uuid, 'Sites', 'sites', 1),
 ('b18b0fc1-237e-4faf-a173-cb98541a4c9c'::uuid, 'Streaming', 'streaming', 2),
 ('8bfbb1bf-fd29-4101-b25d-9d61490ddd4a'::uuid, 'WhatsApp', 'whatsapp', 3),
 ('6f81287d-1b18-4e25-9503-a341dc0e2233'::uuid, 'IA', 'ia', 4),
 ('b09ac6be-fa27-4241-8304-61054d7f8a30'::uuid, 'Trading', 'trading', 5),
 ('324967cf-2f3a-4059-93b9-2d4a8d391d16'::uuid, 'Painéis', 'paineis', 6),
 ('8ecc1f46-b0bc-47e3-9457-44be2b779db3'::uuid, 'Apps', 'apps', 7),
 ('e8d1641a-1b4f-4922-a305-9b425dea7a04'::uuid, 'E-commerce', 'ecommerce', 8),
 ('be96d717-71d7-46b3-bbe6-98aa5df00963'::uuid, 'Marketing', 'marketing', 9);

INSERT INTO public.produtos (id, titulo, descricao, imagem_url, preco, parcelamento, selo, desconto, categoria_id, checkout_url, video_url, demo_url, destaque, ativo, ordem, popup_video_url, popup_video_tipo, popup_imagem_url, preco_antigo, secao, tags, comprar_texto, comprar_provedor, demo_texto) VALUES
 ('1b021673-1715-47b0-aa3f-b0d0a1d45e36'::uuid, 'Agenda PRO', 'Sistema de Agendamento inteligente. Código-fonte completo, pronto para uso.', 'https://minio.afcode.com.br/afcode-uploads/product-covers/products/f1b9af14-fee8-4ba9-98fc-4c3652a5e6f1.webp', 147.90, '12x de R$ 12,35', 'DESTAQUE', 'GANHE ATÉ 50% OFF', 'b18b0fc1-237e-4faf-a173-cb98541a4c9c'::uuid, 'https://wa.me/5571999559427', 'https://www.youtube.com/watch?v=aQzPU4q5rXQ', 'https://wa.me/5571999559427', true, true, 1, 'https://youtube.com/embed/aQzPU4q5rXQ', 'youtube', 'https://minio.afcode.com.br/afcode-uploads/product-covers/products/f1b9af14-fee8-4ba9-98fc-4c3652a5e6f1.webp', 597.00, 'destaque', '{"Micro SAAS"}'::text[], 'Comprar', 'Kiwify', 'Detalhes'),
 ('d3d97eab-e7a6-4feb-8ce1-b0ace613d9de'::uuid, 'Zap Modelo Pro', 'Disparos automáticos, transparentes e seguros em grupos do WhatsApp com painel completo.', '/produtos/bot-atende-ia.jpg', 197.00, '12x de R$ 19,70', 'POPULAR', '60% OFF', '8bfbb1bf-fd29-4101-b25d-9d61490ddd4a'::uuid, 'https://checkout.exemplo.com/zap-modelo-pro', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://wa.me/5571999559427', true, true, 2, NULL, 'auto', '/produtos/bot-atende-ia.jpg', 397.00, 'destaque', '{}'::text[], 'Comprar', 'personalizado', 'Saiba Mais'),
 ('d23d2b0d-a536-4997-9453-5ead86971438'::uuid, 'Lovable Boost', 'Extraia o máximo do seu editor de IA: prompts, templates e boosters para seus projetos.', '/produtos/ia-conteudo.jpg', 97.00, '6x de R$ 16,17', 'NOVO', 'LANÇAMENTO', '6f81287d-1b18-4e25-9503-a341dc0e2233'::uuid, 'https://checkout.exemplo.com/lovable-boost', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/lovable-boost', true, true, 3, NULL, 'auto', '/produtos/ia-conteudo.jpg', 197.00, 'destaque', '{}'::text[], 'Comprar', 'personalizado', 'Ver Demo'),
 ('b3534b30-6934-4dff-bb60-a5328a01e489'::uuid, 'Crypto Trader Dash', 'Painel de trading com gráficos avançados, alertas e integrações com as principais corretoras.', '/images/product-trading.jpg', 397.00, '12x de R$ 39,70', 'PREMIUM', '50% OFF', 'b09ac6be-fa27-4241-8304-61054d7f8a30'::uuid, 'https://checkout.exemplo.com/crypto-trader-dash', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/crypto-trader-dash', true, true, 4, NULL, 'auto', '/images/product-trading.jpg', 797.00, 'destaque', '{}'::text[], 'Comprar', 'personalizado', 'Ver Demo'),
 ('ad5cae30-679e-41b6-bd64-3dc2d3c79915'::uuid, 'Landing Page Builder', 'Construtor de landing pages de alta conversão com editor visual, formulários e integrações de pagamento.', '/produtos/landing-pro.jpg', 147.00, '6x de R$ 24,50', 'NOVO', '50% OFF', NULL, 'https://checkout.exemplo.com/landing-builder', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/landing-builder', false, true, 10, NULL, 'auto', '/produtos/landing-pro.jpg', 297.00, 'vitrine', '{Sites,Marketing}'::text[], 'Comprar', 'personalizado', 'Ver Demo'),
 ('d045ee76-228f-4c3a-a20e-94134acf2ae8'::uuid, 'ERP Dashboard Pro', 'Sistema completo de gestão com dashboards, relatórios, controle de estoque e financeiro.', '/produtos/erp-financeiro.jpg', 497.00, '12x de R$ 49,70', 'PREMIUM', '45% OFF', NULL, 'https://checkout.exemplo.com/erp-dashboard', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/erp-dashboard', false, true, 11, NULL, 'auto', '/produtos/erp-financeiro.jpg', 897.00, 'vitrine', '{Gestão,Dashboards}'::text[], 'Comprar', 'personalizado', 'Ver Demo'),
 ('e9c6e6d1-6d66-45ed-97fb-d5aa9449648c'::uuid, 'Delivery App Completo', 'Aplicativo de delivery com pedidos em tempo real, pagamento online e painel do restaurante.', '/produtos/delivery-app.jpg', 347.00, '12x de R$ 34,70', 'POPULAR', '50% OFF', NULL, 'https://checkout.exemplo.com/delivery-app', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/delivery-app', false, true, 12, NULL, 'auto', '/produtos/delivery-app.jpg', 697.00, 'vitrine', '{Apps,Delivery}'::text[], 'Comprar', 'personalizado', 'Ver Demo'),
 ('b474f306-b0ba-4c22-b2bb-6658d37f993c'::uuid, 'Agenda & Agendamentos', 'Plataforma de agendamento online com lembretes automáticos por WhatsApp e link público de reservas.', '/produtos/agenda-salao.jpg', 197.00, '10x de R$ 19,70', 'DESTAQUE', '50% OFF', NULL, 'https://checkout.exemplo.com/agenda-online', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://exemplo.com/demo/agenda-online', false, true, 13, NULL, 'auto', '/produtos/agenda-salao.jpg', 397.00, 'vitrine', '{Apps,Automação}'::text[], 'Comprar', 'personalizado', 'Ver Demo');

INSERT INTO public.configuracoes (id, chave, valor) VALUES
 ('5d8933ec-4781-4282-861f-a55909e02501'::uuid, 'ajuda', '{"ativo": true, "icone": "telefone", "texto": "Precisa de Ajuda?", "numero": "5571999559427", "posicao": "bottom-left", "tamanho": "pequeno", "mensagem": "Olá! Preciso de ajuda para escolher um produto da loja.", "cor_fundo": "#25D366", "cor_texto": "#ffffff"}'::jsonb),
 ('d9e6f5b6-d7d2-45bf-bdab-ef06869ab172'::uuid, 'banner', '{"tipo": "youtube", "ativo": true, "titulo": "Códigos-fonte, automações e IA prontos para vender", "mp4_url": "", "posicao": "center", "autoplay": false, "capa_url": "", "controles": false, "cor_fundo": "", "cor_texto": "", "descricao": "Marketplace de produtos digitais premium para você lançar seu próprio negócio em minutos.", "subtitulo": "Lançamento", "video_url": "https://www.youtube.com/embed/xFLaqcsRP40"}'::jsonb);

CREATE POLICY "Admins gerenciam arquivos da loja"
  ON storage.objects FOR ALL TO authenticated
  USING      (bucket_id = 'loja' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'loja' AND public.has_role(auth.uid(), 'admin'));